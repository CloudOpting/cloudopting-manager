angular.module('app').constant('URL', 'data/');

angular.module('app').factory('EntityService', function ($http, URL) {
    var getData = function () {
		console.log("in getdata"+URL);
        return $http.get(URL + 'entity.json');
    };

    return {
        getData: getData
    };
});

angular.module('app').factory('CustomService', function ($http, URL) {
    var getData = function () {
		console.log("in getdata"+URL);
        return $http.get(URL + 'custom.json');
    };

    return {
        getData: getData
    };
});

angular.module('app').controller('FormGenerationController', function ($scope,EntityService,CustomService) {
console.log("in controller");
	fetchContent = function () {
		console.log("in fetch");
        EntityService.getData().then(function (result) {
			console.log("in get data" + result);
            $scope.entity = result.data;
        });
    };

    fetchContent();

	fetchCustom = function () {
		console.log("in fetchCustom");
        CustomService.getData().then(function (result) {
			console.log("in get data" + result);
            $scope.fields = result.data;
        });
    };

    fetchCustom();
	// entity to edit
  /*
  $scope.entity = {
    name: 'Max',
	sla: 0,
    country: 2,
    licenceAgreement: true,
    description: 'I use AngularJS'
  };
*/
  // fields description of entity
//  $scope.fields = ;

});